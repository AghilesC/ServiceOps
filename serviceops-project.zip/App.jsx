import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  CheckCircle, 
  Clock, 
  Shield, 
  Database, 
  Calendar, 
  Send, 
  FileText,
  Users,
  TrendingUp,
  Award,
  Lock,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  Zap,
  BarChart3,
  Settings
} from 'lucide-react';

// Composant ScrollToTop pour gérer le défilement entre les pages
const ScrollToTop = () => {
  const { pathname } = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  
  return null;
};

// Page d'accueil
const HomePage = () => {
  const navigate = useNavigate();
  
  const scrollToContact = () => {
    navigate('/contact');
  };

  return (
    <>
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">
              Dites adieu au papier.
              <span className="hero-subtitle">Simplifiez vos interventions.</span>
            </h1>
            <p className="hero-description">
              Transformez vos bons de travail papier en rapports numériques signés et envoyés automatiquement. 
              Une solution complète pour les techniciens sur site : CVC, plomberie, électricité.
            </p>
            <div className="hero-buttons">
              <button onClick={scrollToContact} className="btn btn-primary">
                <Send className="icon-sm" />
                Demander une démo
              </button>
              <button onClick={scrollToContact} className="btn btn-secondary">
                <Phone className="icon-sm" />
                Parler à Aghiles
              </button>
            </div>
            <div className="hero-badges">
              <div className="badge">
                <CheckCircle className="icon-xs" />
                <span>100% RGPD</span>
              </div>
              <div className="badge">
                <Shield className="icon-xs" />
                <span>Données sécurisées</span>
              </div>
              <div className="badge">
                <Clock className="icon-xs" />
                <span>Disponible 24/7</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Comment ça marche */}
      <section className="section bg-light">
        <div className="container">
          <h2 className="section-title">Comment ça marche</h2>
          <p className="section-subtitle">
            Un processus simple en 4 étapes pour digitaliser vos interventions
          </p>
          <div className="process-grid">
            <div className="process-step">
              <div className="process-number">1</div>
              <FileText className="process-icon" />
              <h3>Remplir</h3>
              <p>Le technicien complète le bon de travail numérique sur tablette ou smartphone</p>
            </div>
            <div className="process-step">
              <div className="process-number">2</div>
              <CheckCircle className="process-icon" />
              <h3>Signer</h3>
              <p>Signature électronique du client directement sur l'appareil mobile</p>
            </div>
            <div className="process-step">
              <div className="process-number">3</div>
              <Send className="process-icon" />
              <h3>Envoyer</h3>
              <p>Envoi automatique du rapport au client et à votre base de données</p>
            </div>
            <div className="process-step">
              <div className="process-number">4</div>
              <TrendingUp className="process-icon" />
              <h3>Facturer</h3>
              <p>Génération automatique des factures et suivi des paiements</p>
            </div>
          </div>
        </div>
      </section>

      {/* Fonctionnalités clés */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Fonctionnalités clés</h2>
          <p className="section-subtitle">
            Tout ce dont vous avez besoin pour gérer vos interventions terrain
          </p>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <FileText className="feature-icon" />
              </div>
              <h3>Bons de travail signés</h3>
              <p>Créez et faites signer vos bons de travail électroniquement. Fini les papiers perdus ou illisibles.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <Send className="feature-icon" />
              </div>
              <h3>Envoi automatique temps réel</h3>
              <p>Recevez vos bons de travail signés en temps réel, dès que le technicien a terminé.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <Database className="feature-icon" />
              </div>
              <h3>Base d'équipements</h3>
              <p>Base d'équipements unifiée : historique, numéros de série, interventions, photos.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <Calendar className="feature-icon" />
              </div>
              <h3>Calendrier intelligent</h3>
              <p>Planifiez vos techniciens et synchronisez vos opérations en un clin d'œil.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <BarChart3 className="feature-icon" />
              </div>
              <h3>Historique centralisé</h3>
              <p>Accédez à l'historique complet de chaque client et équipement en quelques clics.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <Lock className="feature-icon" />
              </div>
              <h3>Sécurité renforcée</h3>
              <p>Données chiffrées et sauvegardées automatiquement. Conformité RGPD garantie.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Bénéfices */}
      <section className="section bg-gradient">
        <div className="container">
          <h2 className="section-title text-white">Les bénéfices pour votre entreprise</h2>
          <p className="section-subtitle text-white-80">
            Transformez votre façon de travailler et boostez votre productivité
          </p>
          <div className="benefits-grid">
            <div className="benefit-card">
              <Zap className="benefit-icon" />
              <h3>Gain de temps</h3>
              <p>Économisez 2h par jour en moyenne sur l'administratif</p>
              <div className="benefit-stat">+30%</div>
              <span className="benefit-label">de productivité</span>
            </div>
            <div className="benefit-card">
              <Shield className="benefit-icon" />
              <h3>Zéro erreur</h3>
              <p>Éliminez les erreurs de saisie et les oublis</p>
              <div className="benefit-stat">99%</div>
              <span className="benefit-label">de fiabilité</span>
            </div>
            <div className="benefit-card">
              <Database className="benefit-icon" />
              <h3>Traçabilité totale</h3>
              <p>Retrouvez n'importe quelle intervention en 5 secondes</p>
              <div className="benefit-stat">100%</div>
              <span className="benefit-label">traçable</span>
            </div>
            <div className="benefit-card">
              <Users className="benefit-icon" />
              <h3>Visibilité équipe</h3>
              <p>Suivez vos techniciens en temps réel</p>
              <div className="benefit-stat">24/7</div>
              <span className="benefit-label">disponible</span>
            </div>
          </div>
        </div>
      </section>

      {/* Preuves/Confiance */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Ils nous font confiance</h2>
          <p className="section-subtitle">
            Une solution éprouvée et certifiée pour votre tranquillité d'esprit
          </p>
          <div className="trust-grid">
            <div className="trust-card">
              <Award className="trust-icon" />
              <h4>Qualité garantie</h4>
              <p>Solution développée selon les standards les plus élevés de l'industrie</p>
            </div>
            <div className="trust-card">
              <Lock className="trust-icon" />
              <h4>RGPD Compliant</h4>
              <p>Protection totale de vos données et celles de vos clients</p>
            </div>
            <div className="trust-card">
              <Clock className="trust-icon" />
              <h4>Disponibilité 99.9%</h4>
              <p>Service accessible 24/7 avec une infrastructure redondante</p>
            </div>
            <div className="trust-card">
              <Settings className="trust-icon" />
              <h4>Support dédié</h4>
              <p>Accompagnement personnalisé pour votre réussite</p>
            </div>
          </div>
          <div className="cta-section">
            <h3>Prêt à transformer votre activité ?</h3>
            <p>Découvrez comment ServiceOps peut révolutionner votre gestion des interventions</p>
            <button onClick={scrollToContact} className="btn btn-primary btn-lg">
              <Calendar className="icon-sm" />
              Planifier une démo gratuite
            </button>
          </div>
        </div>
      </section>
    </>
  );
};

// Page À propos
const AboutPage = () => {
  return (
    <div className="page-container">
      <section className="section">
        <div className="container">
          <h1 className="page-title">À propos de ServiceOps</h1>
          
          <div className="about-content">
            <div className="about-section">
              <h2>Qui suis-je ?</h2>
              <p className="lead">
                Je suis <strong>Aghiles CHAOUCHE</strong>, auto-entrepreneur et créateur de ServiceOps.
              </p>
              <p>
                Fort d'une expérience significative dans le domaine de la digitalisation des processus métiers, 
                j'ai constaté que de nombreux techniciens sur le terrain perdent un temps précieux avec 
                la paperasse administrative. C'est pourquoi j'ai développé ServiceOps : une solution 
                complète pour transformer et automatiser la gestion des interventions terrain.
              </p>
              <p className="highlight-box">
                <strong>Note importante :</strong> Ce site m'appartient en tant qu'auto-entrepreneur. 
                Je suis personnellement responsable de la qualité du service et de la protection de vos données.
              </p>
            </div>

            <div className="about-section">
              <h2>Notre Vision</h2>
              <p>
                Digitaliser complètement les opérations terrain pour que les techniciens puissent 
                se concentrer sur leur cœur de métier : servir leurs clients avec excellence.
              </p>
            </div>

            <div className="about-section">
              <h2>Notre Mission</h2>
              <p>
                Fournir aux entreprises de services techniques (CVC, plomberie, électricité) une 
                plateforme simple, fiable et sécurisée pour gérer leurs interventions, leurs équipements 
                et leurs clients en temps réel.
              </p>
            </div>

            <div className="about-section">
              <h2>Nos Valeurs</h2>
              <div className="values-grid">
                <div className="value-card">
                  <Shield className="value-icon" />
                  <h3>Fiabilité</h3>
                  <p>Un système sur lequel vous pouvez compter 24/7</p>
                </div>
                <div className="value-card">
                  <Zap className="value-icon" />
                  <h3>Simplicité</h3>
                  <p>Une interface intuitive que tout le monde peut utiliser</p>
                </div>
                <div className="value-card">
                  <Lock className="value-icon" />
                  <h3>Sécurité</h3>
                  <p>Vos données sont protégées selon les normes les plus strictes</p>
                </div>
                <div className="value-card">
                  <Clock className="value-icon" />
                  <h3>Temps réel</h3>
                  <p>Des informations instantanées pour des décisions éclairées</p>
                </div>
              </div>
            </div>

            <div className="about-section">
              <h2>Responsabilités légales</h2>
              <p>
                En tant qu'auto-entrepreneur, je suis personnellement engagé dans la réussite de votre 
                projet de digitalisation. ServiceOps est une marque déposée appartenant à 
                Aghiles CHAOUCHE, auto-entrepreneur immatriculé en France.
              </p>
              <p>
                Je m'engage à respecter l'ensemble de la réglementation en vigueur, notamment 
                en matière de protection des données personnelles (RGPD) et de sécurité informatique.
              </p>
            </div>

            <div className="cta-section">
              <h3>Envie d'en savoir plus ?</h3>
              <p>Discutons de vos besoins et voyons comment ServiceOps peut vous aider</p>
              <Link to="/contact" className="btn btn-primary btn-lg">
                <Mail className="icon-sm" />
                Me contacter directement
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

// Page Contact
const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    sector: '',
    message: '',
    requestDemo: false,
    acceptContact: false
  });

  const [formStatus, setFormStatus] = useState({
    type: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation supplémentaire
    if (!formData.acceptContact) {
      setFormStatus({
        type: 'error',
        message: 'Veuillez accepter d\'être contacté pour continuer.'
      });
      return;
    }

    // Simulation d'envoi
    console.log('Données du formulaire envoyées:', formData);
    
    setFormStatus({
      type: 'loading',
      message: 'Envoi en cours...'
    });

    // Simuler un délai d'envoi
    setTimeout(() => {
      // TODO: Implémenter l'envoi réel vers un backend
      setFormStatus({
        type: 'success',
        message: 'Merci pour votre message ! Aghiles vous contactera dans les 24 heures.'
      });
      
      // Réinitialiser le formulaire après succès
      setFormData({
        name: '',
        company: '',
        email: '',
        phone: '',
        sector: '',
        message: '',
        requestDemo: false,
        acceptContact: false
      });
    }, 1500);
  };

  return (
    <div className="page-container">
      <section className="section">
        <div className="container">
          <h1 className="page-title">Contactez-nous</h1>
          <p className="page-subtitle">
            Prêt à digitaliser vos interventions ? Parlons de votre projet !
          </p>

          <div className="contact-content">
            <div className="contact-info">
              <h2>Parlons de votre projet</h2>
              <p>
                Que vous soyez une petite entreprise ou un grand groupe, ServiceOps s'adapte 
                à vos besoins. Contactez-moi directement pour une démonstration personnalisée.
              </p>
              
              <div className="contact-details">
                <div className="contact-item">
                  <Mail className="contact-icon" />
                  <div>
                    <h4>Email</h4>
                    <p>contact@serviceops.fr</p>
                  </div>
                </div>
                <div className="contact-item">
                  <Phone className="contact-icon" />
                  <div>
                    <h4>Téléphone</h4>
                    <p>Sur demande après premier contact</p>
                  </div>
                </div>
                <div className="contact-item">
                  <MapPin className="contact-icon" />
                  <div>
                    <h4>Localisation</h4>
                    <p>France - Service disponible partout</p>
                  </div>
                </div>
              </div>

              <div className="trust-section">
                <h3>Pourquoi nous choisir ?</h3>
                <ul className="trust-list">
                  <li>
                    <CheckCircle className="icon-xs" />
                    Réponse sous 24h garantie
                  </li>
                  <li>
                    <CheckCircle className="icon-xs" />
                    Démonstration gratuite et sans engagement
                  </li>
                  <li>
                    <CheckCircle className="icon-xs" />
                    Accompagnement personnalisé
                  </li>
                  <li>
                    <CheckCircle className="icon-xs" />
                    Solution 100% française
                  </li>
                </ul>
              </div>
            </div>

            <div className="contact-form-wrapper">
              <form onSubmit={handleSubmit} className="contact-form">
                <div className="form-group">
                  <label htmlFor="name">Nom complet *</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="Jean Dupont"
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="company">Entreprise *</label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    required
                    placeholder="Nom de votre société"
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email professionnel *</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    placeholder="jean.dupont@entreprise.fr"
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="phone">Téléphone *</label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    pattern="[0-9]{10}"
                    placeholder="0612345678"
                    className="form-input"
                  />
                  <small className="form-hint">Format : 10 chiffres sans espaces</small>
                </div>

                <div className="form-group">
                  <label htmlFor="sector">Secteur d'activité *</label>
                  <select
                    id="sector"
                    name="sector"
                    value={formData.sector}
                    onChange={handleChange}
                    required
                    className="form-input"
                  >
                    <option value="">Sélectionnez votre secteur</option>
                    <option value="cvc">CVC / Climatisation</option>
                    <option value="plomberie">Plomberie</option>
                    <option value="electricite">Électricité</option>
                    <option value="multi">Multi-technique</option>
                    <option value="autre">Autre</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="message">Votre message</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows="5"
                    placeholder="Décrivez votre besoin ou posez vos questions..."
                    className="form-input"
                  />
                </div>

                <div className="form-checkbox-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      name="requestDemo"
                      checked={formData.requestDemo}
                      onChange={handleChange}
                    />
                    <span>Je souhaite une démonstration gratuite</span>
                  </label>

                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      name="acceptContact"
                      checked={formData.acceptContact}
                      onChange={handleChange}
                      required
                    />
                    <span>J'accepte d'être contacté par Aghiles CHAOUCHE *</span>
                  </label>
                </div>

                <div className="rgpd-notice">
                  <Lock className="icon-xs" />
                  <p>
                    <strong>Protection de vos données (RGPD)</strong><br />
                    Vos informations sont stockées de manière sécurisée et utilisées uniquement 
                    dans le cadre de votre demande de contact ou de démonstration. Elles ne sont 
                    jamais partagées avec des tiers. Vous pouvez demander leur suppression à tout moment.
                  </p>
                </div>

                {formStatus.message && (
                  <div className={`form-status ${formStatus.type}`}>
                    {formStatus.message}
                  </div>
                )}

                <button type="submit" className="btn btn-primary btn-block">
                  <Send className="icon-sm" />
                  Envoyer ma demande
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

// Composant Navigation
const Navigation = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="container">
        <div className="navbar-content">
          <Link to="/" className="navbar-brand">
            <span className="brand-text">ServiceOps</span>
          </Link>
          
          <div className={`navbar-menu ${mobileMenuOpen ? 'mobile-open' : ''}`}>
            <Link 
              to="/" 
              className={`navbar-link ${location.pathname === '/' ? 'active' : ''}`}
              onClick={closeMobileMenu}
            >
              Accueil
            </Link>
            <Link 
              to="/a-propos" 
              className={`navbar-link ${location.pathname === '/a-propos' ? 'active' : ''}`}
              onClick={closeMobileMenu}
            >
              À propos
            </Link>
            <Link 
              to="/contact" 
              className={`navbar-link ${location.pathname === '/contact' ? 'active' : ''}`}
              onClick={closeMobileMenu}
            >
              Contact
            </Link>
          </div>
          
          <button className="mobile-menu-toggle" onClick={toggleMobileMenu}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>
    </nav>
  );
};

// Composant Footer
const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3>ServiceOps</h3>
            <p>La solution de digitalisation pour les techniciens sur site.</p>
            <p className="footer-ownership">
              <strong>© {currentYear} Aghiles CHAOUCHE</strong><br />
              Ce site m'appartient - Auto-entrepreneur
            </p>
          </div>
          
          <div className="footer-section">
            <h4>Navigation</h4>
            <ul className="footer-links">
              <li><Link to="/">Accueil</Link></li>
              <li><Link to="/a-propos">À propos</Link></li>
              <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4>Mentions légales</h4>
            <p>
              Propriétaire : Aghiles CHAOUCHE<br />
              Statut : Auto-entrepreneur<br />
              Email : contact@serviceops.fr<br />
              Hébergement : France
            </p>
          </div>
          
          <div className="footer-section">
            <h4>Conformité</h4>
            <div className="footer-badges">
              <div className="footer-badge">
                <Shield className="icon-xs" />
                <span>RGPD</span>
              </div>
              <div className="footer-badge">
                <Lock className="icon-xs" />
                <span>SSL</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>Tous droits réservés - ServiceOps est une marque appartenant à Aghiles CHAOUCHE</p>
        </div>
      </div>
    </footer>
  );
};

// Application principale
function App() {
  useEffect(() => {
    // SEO Meta tags
    document.title = "ServiceOps - Digitalisation des interventions terrain | Aghiles CHAOUCHE";
    
    // Meta descriptions
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.content = "ServiceOps par Aghiles CHAOUCHE : Solution complète de digitalisation pour techniciens. Bons de travail numériques, signatures électroniques, envoi automatique.";
    }
    
    // Open Graph tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.content = "ServiceOps - Digitalisation des interventions terrain";
    }
    
    const ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.content = "Transformez vos bons de travail papier en rapports numériques signés. Solution pour CVC, plomberie, électricité.";
    }
  }, []);

  return (
    <Router>
      <ScrollToTop />
      <div className="app">
        <Navigation />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/a-propos" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;